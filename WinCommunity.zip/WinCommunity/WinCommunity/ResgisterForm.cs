﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WinCommunity
{
    public partial class ResgisterForm : Form
    {
        public ResgisterForm()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click(object sender, EventArgs e)
        {

        }

        private void btnUpload_Click_1(object sender, EventArgs e)
        {
            // Спеціальне вікно - де можна обрати файл
            OpenFileDialog myDialog = new OpenFileDialog();

            // Додаємо фільтр, щоб зручно обирати картинки, але залишаємо "Усі файли" для тестування помилки
            myDialog.Filter = "Зображення|*.jpg;*.jpeg;*.png;*.bmp|Усі файли|*.*";

            // Для відображення вікна використовується метод ShowDialog() і умовний оператор if
            // DialogResult.OK - це якщо користувач обрав файл на ПК
            if (myDialog.ShowDialog() == DialogResult.OK)
            {
                string filePath = myDialog.FileName;

                // Шлях до файлу вписуємо у текстовий напис на формі
                label1.Text = filePath;

                // Перевіряємо, чи файл дійсно є зображенням
                try
                {
                    // Виводимо фото у PictureBox
                    pictureBox1.Image = Image.FromFile(filePath);
                }
                catch (Exception)
                {
                    // Якщо користувач обрав файл, який не підтримується (наприклад, .txt)
                    MessageBox.Show("Обраний файл не підтримується! Будь ласка, виберіть зображення.", "Помилка формату", MessageBoxButtons.OK, MessageBoxIcon.Error);

                    // Очищаємо напис і картинку
                    label1.Text = "";
                    pictureBox1.Image = null;
                }
            }

        }
    }
}
