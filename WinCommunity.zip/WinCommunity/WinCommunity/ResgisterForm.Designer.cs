﻿namespace WinCommunity
{
    partial class ResgisterForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            pictureBox1 = new PictureBox();
            label1 = new Label();
            btnUpload = new Button();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // pictureBox1
            // 
            pictureBox1.BorderStyle = BorderStyle.FixedSingle;
            pictureBox1.Location = new Point(21, 12);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(259, 265);
            pictureBox1.SizeMode = PictureBoxSizeMode.Zoom;
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Comic Sans MS", 11.25F, FontStyle.Bold, GraphicsUnit.Point, 204);
            label1.ForeColor = Color.FromArgb(64, 64, 64);
            label1.Location = new Point(21, 280);
            label1.Name = "label1";
            label1.Size = new Size(0, 21);
            label1.TabIndex = 1;
            label1.Click += label1_Click;
            // 
            // btnUpload
            // 
            btnUpload.BackColor = SystemColors.GradientActiveCaption;
            btnUpload.Font = new Font("Comic Sans MS", 16F, FontStyle.Bold);
            btnUpload.ForeColor = Color.FromArgb(64, 64, 64);
            btnUpload.Location = new Point(53, 319);
            btnUpload.Name = "btnUpload";
            btnUpload.Size = new Size(165, 46);
            btnUpload.TabIndex = 3;
            btnUpload.Text = "Завантажити";
            btnUpload.UseVisualStyleBackColor = false;
            btnUpload.Click += btnUpload_Click_1;
            // 
            // ResgisterForm
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(304, 389);
            Controls.Add(btnUpload);
            Controls.Add(label1);
            Controls.Add(pictureBox1);
            Name = "ResgisterForm";
            Text = "ResgisterForm";
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private PictureBox pictureBox1;
        private Label label1;
        private Button btnUpload;
    }
}